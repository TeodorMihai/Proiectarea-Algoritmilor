#include <bits/stdc++.h>

using namespace std;

 int v[] = {-2, 1, -3, 4 , -1, 2, 1, -5, 4};


int findSubs(int st, int dr, int* v, int& sum, int& pre, int& post) {

	if(st == dr) {

		pre = max(0, v[st]);
		post = max(0, v[st]);
		sum = v[st];
		return max(0, sum);
	}

	int mid = st + (dr - st) / 2;

	int sum1; int sum2 ; int pre1; int pre2; int post1; int post2;

	int bst1 = findSubs(st, mid, v, sum1, pre1, post1);
	int bst2 = findSubs(mid + 1, dr, v, sum2, pre2, post2);

	sum = sum1 + sum2;
	pre = max(sum1 + pre2, pre1);
	post = max(post1 + sum2, post2);

	return max(bst1, max(bst2, pre2 + post1) ) ;
}

int main() {

	int a, b, c;
	cout << findSubs(0, 8, v,a, b, c ) << '\n'; 


	return 0;
}